/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author RC_Student_lab
 */
public class ChatApp {
    private static boolean isLoggedIn = false;
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();

    public static void main(String[] args) {
        // Simulate user login
        loginUser ();

        if (isLoggedIn) {
            displayWelcomeMessage();
            showMenu();
        }
    }

    private static void loginUser () {
        // Simulate login process
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");

        // For simplicity, assume any non-empty username and password is valid
        if (!username.isEmpty() && !password.isEmpty()) {
            isLoggedIn = true;
            JOptionPane.showMessageDialog(null, "Welcome " + username + ", it is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again.");
        }
    }

    private static void displayWelcomeMessage() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
    }

    private static void showMenu() {
        while (true) {
            String menu = "Choose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit";
            String choice = JOptionPane.showInputDialog(menu);

            switch (choice) {
                case "1" -> sendMessage();
                case "2" -> showRecentlySentMessages();
                case "3" -> {
                    JOptionPane.showMessageDialog(null, "Exiting the application.");
                    return;
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        }
    }

    private static void sendMessage() {
        int numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you wish to enter?"));
        for (int i = 0; i < numMessages; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient's cell number:");
            String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");

            if (messageText.length() > 250) {
                JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
                continue;
            }

            Message message = new Message(recipient, messageText);
            String action = JOptionPane.showInputDialog("Choose an action:\n1) Send Message\n2) Disregard Message\n3) Store Message to send later");

            switch (action) {
                case "1" -> {
                    sentMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message sent: " + message);
                }
                case "2" -> {
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
                case "3" -> {
                    storedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message stored.");
                }
                default -> {
                    JOptionPane.showMessageDialog(null, "Invalid action. Message disregarded.");
                    disregardedMessages.add(message);
                }
            }
        }
    }

    private static void showRecentlySentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        StringBuilder messageList = new StringBuilder("Recently sent messages:\n");
        for (Message msg : sentMessages) {
            messageList.append(msg.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, messageList.toString());
    }
}

class Message {
    private final String recipient;
    private final String messageText;
    private final String messageId;
    private final String messageHash;

    public Message(String recipient, String messageText) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageId = generateMessageId();
        this.messageHash = createMessageHash();
    }

    private String generateMessageId() {
        Random random = new Random();
        return String.format("%010d", random.nextInt(1000000000)); // Generate a random 10-digit number
    }

    private String createMessageHash() {
        String[] words = messageText.split(" ");
        return messageId.substring(0, 2) + ":0:" + words[0].toUpperCase() + words[words.length - 1].toUpperCase();
    }

    @Override
    public String toString() {
        return "Message ID: " + messageId + ", Recipient: " + recipient + ", Message: " + messageText + ", Hash: " + messageHash;
    }
}

